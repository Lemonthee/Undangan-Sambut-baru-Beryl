# Undangan Komuni Beryl

Proyek ini berisi undangan digital untuk Komuni Beryl.

## Isi
- `index.html`: Halaman utama undangan
- `assets/musik-komuni.mp3`: Musik latar
- `assets/vintage-bg.jpg`: Background vintage

## Cara Menjalankan
Cukup buka `index.html` di browser modern. Musik akan otomatis diputar (jika diizinkan oleh browser).
